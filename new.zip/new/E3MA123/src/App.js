import Header from './components/Header'
import NavItem from './components/NavItem'
import Footer from './components/Footer'
import Main from './components/Main'
import Favourite from './components/Favourite';

function App() {
  return (
    <div className= "container">
      
      
      <Header title="Car Gallery" />
      <NavItem text="Home" itemNumber="1" />
      <NavItem text="Get Started" itemNumber="2" />
      <NavItem text="Photos" itemNumber="3" />
      <NavItem text="Gear" itemNumber="4" />
      <NavItem text="Forum" itemNumber="5" />
      <Main title="WELCOME"
      text="Welcome to our car gallery this is not sponsored please dont tell to the police or report our site hahaha. if this is a real website of the car gallery you will have an idea what car do you want in the near future you will have a simple idea of this cars. So don't waste your time and   look what kind of car that you want!"/>

      <Favourite line1="Car" line2="Photos"/>

      <Footer text="@ This is a private and non reality website yes its only a fake website for our assignment in It Elective 3 by Sr. Alamo using"
      websiteSource="google.com"/>
    </div>
  );
}

export default App;
